import { LitElement, html, css } from 'lit-element';
import stylesScss from './wcSalonStyle';

class SalonesViews extends LitElement {
  constructor() {
    super();
    this.salones = this.getSalonesFromLocalStorage() || [];
  }

 
  static get styles() {
    return [stylesScss];
  }

  render() {
    return html`
      <div>
        <h1>Lista de Salones</h1>
        <button @click="${() => this.agregarSalon()}">Agregar Salón</button>
        <table>
          <!-- Encabezados de la tabla -->
          <tr>
            <th>ID</th>
            <th>Piso</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
          <!-- Filas de la tabla para mostrar salones -->
          ${this.salones.map(salon => html`
            <tr>
              <td>${salon.ID}</td>
              <td>${salon.PISO}</td>
              <td>
                <button @click="${() => this.toggleEstado(salon)}">${salon.ESTADO}</button>
              </td>
              <td>
                <button @click="${() => this.borrarSalon(salon.ID)}">Borrar</button>
                <button @click="${() => this.actualizarSalon(salon.ID)}">Actualizar</button>
              </td>
            </tr>
          `)}
        </table>
      </div>
    `;
  }

  agregarSalon() {
    const PISO = prompt("Ingrese el piso del salón:");
    const ESTADO = "Activo"; // Por defecto se inicia como "Activo"

    if (PISO) {
      const nuevoSalon = {
        ID: this.salones.length + 1,
        PISO,
        ESTADO,
      };
      this.salones = [...this.salones, nuevoSalon];
      this.saveSalonesToLocalStorage(this.salones);
      this.requestUpdate('salones');
    }
  }

  toggleEstado(salon) {
    // Alternar entre "Activo" e "Inactivo"
    salon.ESTADO = salon.ESTADO === "Activo" ? "Inactivo" : "Activo";
    this.saveSalonesToLocalStorage(this.salones);
    this.requestUpdate('salones');
  }

  borrarSalon(id) {
    this.salones = this.salones.filter(salon => salon.ID !== id);
    this.saveSalonesToLocalStorage(this.salones);
    this.requestUpdate('salones');
  }

  actualizarSalon(id) {
    const salon = this.salones.find(salon => salon.ID === id);
    if (salon) {
      const PISO = prompt("Nuevo piso del salón:", salon.PISO);

      if (PISO !== null) {
        salon.PISO = PISO;
        this.saveSalonesToLocalStorage(this.salones);
        this.requestUpdate('salones');
      }
    }
  }

  saveSalonesToLocalStorage(salones) {
    localStorage.setItem('salones', JSON.stringify(salones));
  }

  getSalonesFromLocalStorage() {
    const salones = localStorage.getItem('salones');
    return salones ? JSON.parse(salones) : [];
  }
}

customElements.define('salones-views', SalonesViews);
