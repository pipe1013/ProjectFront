import { css } from "lit-element";

export default css`
/* Estilo para el contenedor principal */
div {
  text-align: center; /* Centra el contenido del div */
}

/* Estilo para el título */
h1 {
  margin: 0; /* Elimina el margen superior predeterminado */
}

/* Estilo para el botón "Agregar Curso" */
#agregar-button {
  float: right;
  margin-right: 20px;
  margin-top: 0px;
}

/* Estilo para la tabla */
#cursos-list {
  width: 90%;
  margin:20px
  border-collapse: collapse;
  margin-top: 40px;
}

#cursos-list th, #cursos-list td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: center;
  height: 30px; /* Altura fija de las filas */
}

/* Estilo para los botones */
button {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
  margin-right: 5px;
}

button:hover {
  background-color: #0056b3;
}

/* Estilo para el botón de "Agregar Curso" */
#agregar-button {
  float: right;
  margin-right: 20px;
  margin-top: 20px;
}

`;