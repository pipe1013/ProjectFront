import { LitElement, html } from 'lit-element';
import stylesScss from './wcCursosStyle';

class CursosViews extends LitElement {
  constructor() {
    super();
    this.cursos = [
      { ID: 1,
         PROFESOR: 'Juan Pérez', 
         ESTUDIANTE: 'María García', 
         JORNADA: 'Mañana',
          SALON: '101' },
      { ID: 2, 
        PROFESOR: 'Ana López',
         ESTUDIANTE: 'Pedro Rodríguez',
          JORNADA: 'Tarde', 
          SALON: '201' }
    ];
  }

  static get styles() {
    return [stylesScss];
  }

  render() {
    return html`
      <div>
        <h1>Lista de Cursos</h1>
        <button style="float: left; font-size: 18px;" @click="${() => this.agregarCurso()}">Agregar Curso</button>
        <table id="cursos-list">
          <tr>
            ${Object.keys(this.cursos[0]).map(attr => html`
              <th>${attr}</th>
            `)}
            <th>Acciones</th>
          </tr>
          ${this.cursos.map(curso => html`
            <tr>
              ${Object.values(curso).map(val => html`
                <td>${val}</td>
              `)}
              <td>
                <button @click="${() => this.borrarCurso(curso.ID)}">Borrar</button>
                <button @click="${() => this.actualizarCurso(curso.ID)}">Actualizar</button>
              </td>
            </tr>
          `)}
        </table>
      </div>
    `;
  }
  
  agregarCurso() {
    const PROFESOR = prompt("Ingrese el nombre del profesor:");
    const ESTUDIANTE = prompt("Ingrese el nombre del estudiante:");
    const JORNADA = prompt("Ingrese la jornada:");
    const SALON = prompt("Ingrese el salón:");

    if (PROFESOR && ESTUDIANTE && JORNADA && SALON) {
      const nuevoCurso = {
        ID: this.cursos.length + 1,
        PROFESOR,
        ESTUDIANTE,
        JORNADA,
        SALON
      };
      this.cursos = [...this.cursos, nuevoCurso];
      this.requestUpdate('cursos');
    }
  }

  actualizarCurso(id) {
    const curso = this.cursos.find(curso => curso.ID === id);
    if (curso) {
      const PROFESOR = prompt("Nuevo nombre del profesor:", curso.PROFESOR);
      const ESTUDIANTE = prompt("Nuevo nombre del estudiante:", curso.ESTUDIANTE);
      const JORNADA = prompt("Nueva jornada:", curso.JORNADA);
      const SALON = prompt("Nuevo salón:", curso.SALON);

      if (PROFESOR !== null && ESTUDIANTE !== null && JORNADA !== null && SALON !== null) {
        curso.PROFESOR = PROFESOR;
        curso.ESTUDIANTE = ESTUDIANTE;
        curso.JORNADA = JORNADA;
        curso.SALON = SALON;
        this.requestUpdate('cursos');
      }
    }
  }

  borrarCurso(id) {
    this.cursos = this.cursos.filter(curso => curso.ID !== id);
    this.requestUpdate('cursos');
  }
}

customElements.define('cursos-views', CursosViews);
